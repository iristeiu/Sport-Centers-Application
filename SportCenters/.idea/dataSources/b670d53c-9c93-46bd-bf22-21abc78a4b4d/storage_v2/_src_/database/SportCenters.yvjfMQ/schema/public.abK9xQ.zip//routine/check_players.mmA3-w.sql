create function check_players() returns trigger
    language plpgsql
as
$$
begin 
	if ( 
		select max_players 
		from sport s
		join sport_field sf on s.sport_id = sf.sport_id
		join field f on f.field_id = sf.field_id
		where f.field_id = new.field_id	
		)<=(
		select count(*)
		from members m
		join _groups g on m.group_id = g.group_id
		where g.group_id = new.reserved_by
		group by m.group_id
		)
		then 
			raise exception 'The team is already full!';
		end if;
	return new;
end
$$;

alter function check_players() owner to postgres;

