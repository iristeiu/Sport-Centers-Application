create view mygroupdetails(group_name, person_id, last_name, first_name, status) as
SELECT g.group_name,
       p.person_id,
       p.last_name,
       p.first_name,
       CASE
           WHEN m.status_admin = true THEN 'LEADER'::character varying
           ELSE 'MEMBER'::character varying
           END AS status
FROM members m
         LEFT JOIN _groups g ON m.group_id = g.group_id
         LEFT JOIN person p ON p.person_id = m.member_id;

alter table mygroupdetails
    owner to postgres;

