create function update_payment() returns trigger
    language plpgsql
as
$$
BEGIN 
    UPDATE payments 
    SET payment_amount = (
        SELECT price_hour * 
               EXTRACT(EPOCH FROM (reservation.end_time - reservation.start_time)) / 3600
        FROM field
        JOIN reservation ON field.field_id = reservation.field_id
        WHERE reservation.reservation_id = NEW.reservation_id
    )
    WHERE reservation_id = NEW.reservation_id;

    UPDATE payments 
    SET paid = FALSE 
    WHERE reservation_id = NEW.reservation_id;

    RETURN NEW;
END;
$$;

alter function update_payment() owner to postgres;

