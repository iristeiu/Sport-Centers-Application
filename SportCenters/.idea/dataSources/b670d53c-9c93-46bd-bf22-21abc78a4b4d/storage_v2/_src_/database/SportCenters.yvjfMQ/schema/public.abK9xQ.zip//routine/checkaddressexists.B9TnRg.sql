create function checkaddressexists(in_country character varying, in_county character varying, in_city character varying, in_address_details character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    address_exists BOOLEAN;
BEGIN
    SELECT EXISTS(
        SELECT 1 FROM address
        WHERE country = in_country
        AND county = in_county
        AND city = in_city
        AND address_details = in_address_details
    ) INTO address_exists;

    RETURN address_exists;
END;
$$;

alter function checkaddressexists(varchar, varchar, varchar, varchar) owner to postgres;

