create view group_players_view(group_name, max_players, group_nr_of_players, available) as
SELECT g.group_name,
       s.max_players,
       count(m.member_id) AS group_nr_of_players,
       CASE
           WHEN s.max_players > count(m.member_id) OR s.max_players IS NULL THEN true
           ELSE false
           END            AS available
FROM _groups g
         LEFT JOIN members m ON g.group_id = m.group_id
         LEFT JOIN sport_field sf ON g.group_id = sf.field_id
         LEFT JOIN sport s ON sf.sport_id = s.sport_id
GROUP BY g.group_id, g.group_name, s.max_players;

alter table group_players_view
    owner to postgres;

