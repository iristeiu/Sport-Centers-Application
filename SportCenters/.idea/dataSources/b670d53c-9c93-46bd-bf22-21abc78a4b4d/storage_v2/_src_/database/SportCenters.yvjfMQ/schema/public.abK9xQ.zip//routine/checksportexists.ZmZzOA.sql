create function checksportexists(in_sport_name character varying, in_max_players integer) returns boolean
    language plpgsql
as
$$
DECLARE
    sport_exists BOOLEAN;
BEGIN
    SELECT EXISTS(
        SELECT 1 FROM sport
        WHERE sport_name = in_sport_name and max_players = in_max_players
    ) INTO sport_exists;

    RETURN sport_exists;
END;
$$;

alter function checksportexists(varchar, integer) owner to postgres;

