create view persondetails
            (person_id, last_name, first_name, date_of_birth, gender, person_status, email, user_password) as
SELECT p.person_id,
       p.last_name,
       p.first_name,
       p.date_of_birth,
       p.gender,
       CASE
           WHEN p.status = 1 THEN 'PLAYER'::character varying
           ELSE 'ADMIN'::character varying
           END AS person_status,
       u.email,
       u.user_password
FROM person p
         LEFT JOIN person_status ps ON ps.id = p.person_id
         LEFT JOIN _user u ON u.user_id = p.person_id;

alter table persondetails
    owner to postgres;

