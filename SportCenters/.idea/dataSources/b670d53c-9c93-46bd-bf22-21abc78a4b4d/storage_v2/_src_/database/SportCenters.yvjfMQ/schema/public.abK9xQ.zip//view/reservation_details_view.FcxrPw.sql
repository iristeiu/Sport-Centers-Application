create view reservation_details_view
            (reservation_id, group_name, reservation_date, hours, sport_name, country, city, address_details,
             group_nr_of_players, available)
as
SELECT r.reservation_id,
       g.group_name,
       r.reservation_date,
       (to_char(r.start_time::interval, 'HH:MI'::text) || '-'::text) ||
       to_char(r.end_time::interval, 'HH:MI'::text) AS hours,
       s.sport_name,
       a.country,
       a.city,
       a.address_details,
       count(m.member_id)                           AS group_nr_of_players,
       CASE
           WHEN s.max_players > count(m.member_id) OR s.max_players IS NULL THEN true
           ELSE false
           END                                      AS available
FROM reservation r
         JOIN _groups g ON r.reserved_by = g.group_id
         LEFT JOIN members m ON g.group_id = m.group_id
         JOIN sport_field sf ON r.field_id = sf.field_id
         JOIN sport s ON sf.sport_id = s.sport_id
         JOIN field f ON sf.field_id = f.field_id
         JOIN address a ON f.address_id = a.address_id
GROUP BY r.reservation_id, g.group_name, r.reservation_date,
         ((to_char(r.start_time::interval, 'HH:MI'::text) || '-'::text) ||
          to_char(r.end_time::interval, 'HH:MI'::text)), s.sport_name, a.country, a.city, a.address_details,
         s.max_players;

alter table reservation_details_view
    owner to postgres;

