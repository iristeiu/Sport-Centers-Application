create view allfielddetails
            (field_id, country, county, city, address_details, price_hour, sport_name, max_players, field_type,
             ventilation_lights, floor_surface)
as
SELECT f.field_id,
       a.country,
       a.county,
       a.city,
       a.address_details,
       f.price_hour,
       s.sport_name,
       s.max_players,
       CASE
           WHEN i.field_id IS NOT NULL THEN 'indoor'::character varying
           ELSE 'outdoor'::character varying
           END AS field_type,
       CASE
           WHEN i.field_id IS NOT NULL THEN i.ventilation
           ELSE of.night_lights
           END AS ventilation_lights,
       CASE
           WHEN i.field_id IS NOT NULL THEN i.floor_material
           ELSE of.surface_nature::character varying
           END AS floor_surface
FROM field f
         LEFT JOIN inside_field i ON i.field_id = f.field_id
         LEFT JOIN outside_field of ON of.field_id = f.field_id
         LEFT JOIN address a ON a.address_id = f.address_id
         LEFT JOIN sport_field sf ON sf.field_id = f.field_id
         LEFT JOIN sport s ON s.sport_id = sf.sport_id;

alter table allfielddetails
    owner to postgres;

